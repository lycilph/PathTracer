using System.Collections.Generic;
using Tracer.Core.Lights;

namespace Tracer.Core.Scene;

public sealed class Scene
{
    public IHittable World { get; }
    public IReadOnlyList<ILight> Lights { get; }

    public Scene(IHittable world, IReadOnlyList<ILight> lights)
    {
        World = world;
        Lights = lights;
    }
}
