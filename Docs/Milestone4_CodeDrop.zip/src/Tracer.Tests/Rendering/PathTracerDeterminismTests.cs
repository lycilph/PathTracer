using System.Collections.Generic;
using Tracer.Core.Camera;
using Tracer.Core.Lights;
using Tracer.Core.Math;
using Tracer.Core.Materials;
using Tracer.Core.Rendering;
using Tracer.Core.Scene;
using Xunit;

namespace Tracer.Tests.Rendering;

public class PathTracerDeterminismTests
{
    [Fact]
    public void Render_IsDeterministic_ForFixedSeed()
    {
        const int width = 8;
        const int height = 8;
        const int spp = 4;
        const int maxDepth = 5;
        const ulong seed = 123;

        var gray = new Lambertian(new Vec3(0.8f, 0.8f, 0.8f));
        var world = new HittableList();
        world.Add(new Sphere(new Vec3(0, 0, -1), 0.5f, gray));
        world.Add(new Sphere(new Vec3(0, -100.5f, -1), 100f, gray));

        var scene = new Scene(world, new List<ILight>());

        var camera = new PinholeCamera(60f, 1f, new Vec3(0, 0, 1), new Vec3(0, 0, -1), Vec3.UnitY);

        var img1 = PathTracer.Render(width, height, spp, maxDepth, camera, scene, baseSeed: seed);
        var img2 = PathTracer.Render(width, height, spp, maxDepth, camera, scene, baseSeed: seed);

        Assert.Equal(img1.Length, img2.Length);
        for (int i = 0; i < img1.Length; i++)
            Assert.Equal(img1[i], img2[i]);
    }
}
