using Tracer.Core.Math;
using Tracer.Core.Materials;
using Tracer.Core.Scene;
using Xunit;

namespace Tracer.Tests.Scene;

public class RectTests
{
    [Fact]
    public void XYRect_Hit_Works()
    {
        var mat = new Lambertian(new Vec3(1,1,1));
        var rect = new XYRect(0, 1, 0, 1, k: 2, mat);

        var ray = new Ray(new Vec3(0.5f, 0.5f, 0), new Vec3(0, 0, 1));
        bool hit = rect.Hit(ray, 0.001f, 1000f, out var rec);

        Assert.True(hit);
        Assert.InRange(rec.T, 1.999f, 2.001f);
        Assert.InRange(rec.Point.Z, 1.999f, 2.001f);
    }

    [Fact]
    public void XYRect_Miss_Works()
    {
        var mat = new Lambertian(new Vec3(1,1,1));
        var rect = new XYRect(0, 1, 0, 1, k: 2, mat);

        var ray = new Ray(new Vec3(2f, 2f, 0), new Vec3(0, 0, 1));
        bool hit = rect.Hit(ray, 0.001f, 1000f, out _);
        Assert.False(hit);
    }
}
