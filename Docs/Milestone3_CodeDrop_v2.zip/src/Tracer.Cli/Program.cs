using System;
using Tracer.Core.Camera;
using Tracer.Core.Math;
using Tracer.Core.Materials;
using Tracer.Core.Rendering;
using Tracer.Core.Scene;

// Milestone 3 CLI entry point.
// Default renders a Cornell box (axis-aligned, no box rotation yet).
// Usage:
//   dotnet run --project src/Tracer.Cli -- <width> <height> <spp> <out.ppm>

int width = 400;
int height = 400;
int spp = 50;
string outPath = "milestone3_cornell.ppm";

if (args.Length >= 3)
{
    int.TryParse(args[0], out width);
    int.TryParse(args[1], out height);
    int.TryParse(args[2], out spp);
}
if (args.Length >= 4) outPath = args[3];

float aspect = (float)width / height;

// Materials
var red = new Lambertian(new Vec3(0.65f, 0.05f, 0.05f));
var green = new Lambertian(new Vec3(0.12f, 0.45f, 0.15f));
var white = new Lambertian(new Vec3(0.73f, 0.73f, 0.73f));
var light = new DiffuseLight(new Vec3(15f, 15f, 15f));

// Cornell box geometry (0..555)
var world = new HittableList();
// Walls (normals are oriented correctly by HitRecord using FrontFace logic)
world.Add(new YZRect(0, 555, 0, 555, 555, green)); // right wall (green)
world.Add(new YZRect(0, 555, 0, 555, 0, red));     // left wall (red)

world.Add(new XZRect(0, 555, 0, 555, 0, white));     // floor
world.Add(new XZRect(0, 555, 0, 555, 555, white));   // ceiling
world.Add(new XYRect(0, 555, 0, 555, 555, white));   // back wall

// Ceiling light (one-sided, emitting downward into the box)
world.Add(new FlipFace(new XZRect(213, 343, 227, 332, 554, light)));

// Two inner boxes (axis-aligned; rotation will be added in a later milestone)
world.Add(new Box(new Vec3(130, 0, 65), new Vec3(295, 165, 230), white));
world.Add(new Box(new Vec3(265, 0, 295), new Vec3(430, 330, 460), white));

// Camera (classic Cornell view)
var camera = new PinholeCamera(
    vfovDegrees: 40f,
    aspectRatio: aspect,
    lookFrom: new Vec3(278f, 278f, -800f),
    lookAt: new Vec3(278f, 278f, 0f),
    vUp: Vec3.UnitY);

Console.WriteLine($"Rendering Cornell {width}x{height}, spp={spp} -> {outPath}");
var pixels = PathTracer.Render(width, height, spp, maxDepth: 10, camera, world, baseSeed: 123);

Tracer.Core.Rendering.PpmWriter.WriteP6(outPath, width, height, pixels);
Console.WriteLine("Done.");
