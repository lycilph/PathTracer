using Tracer.Core.Math;

namespace Tracer.Core.Scene;

/// <summary>
/// Wraps a hittable and flips the reported surface normal orientation.
/// Useful for constructing closed boxes with consistent inward-facing normals.
/// </summary>
public sealed class FlipFace : IHittable
{
    private readonly IHittable _obj;

    public FlipFace(IHittable obj) => _obj = obj;

    public bool Hit(in Ray ray, float tMin, float tMax, out HitRecord hit)
    {
        if (!_obj.Hit(ray, tMin, tMax, out hit))
            return false;

        hit = hit.Flipped();
        return true;
    }
}
