using Tracer.Core.Camera;
using Tracer.Core.Math;
using Tracer.Core.Random;
using Tracer.Core.Scene;
using Tracer.Core.Sampling;

namespace Tracer.Core.Rendering;

/// <summary>
/// Path tracer with emissive materials (Milestone 3).
/// 
/// For diffuse (Lambertian) surfaces, we use cosine-weighted hemisphere sampling.
/// With that sampling choice, throughput update becomes Hadamard(albedo, Li(next)).
/// 
/// NOTE: This integrator does NOT yet implement explicit light sampling or MIS.
/// </summary>
public static class PathTracer
{
    public static Vec3[] Render(
        int width,
        int height,
        int samplesPerPixel,
        int maxDepth,
        PinholeCamera camera,
        IHittable world,
        ulong baseSeed = 1)
    {
        var film = new Vec3[width * height];

        for (int y = 0; y < height; y++)
        for (int x = 0; x < width; x++)
        {
            Vec3 sum = Vec3.Zero;

            for (int s = 0; s < samplesPerPixel; s++)
            {
                ulong seed = SeedHash.PixelSampleSeed(x, y, s, baseSeed);
                var rng = new Pcg32(seed);
                var sampler = new Sampler(rng);

                float u = (x + sampler.Next1D()) / width;
                float v = (y + sampler.Next1D()) / height;
                var ray = camera.GetRay(u, 1f - v);

                sum += Li(ray, world, sampler, maxDepth);
            }

            film[y * width + x] = sum / samplesPerPixel;
        }

        return film;
    }

    private static Vec3 Li(in Ray r, IHittable world, Sampler sampler, int depth)
    {
        if (depth <= 0)
            return Vec3.Zero;

        if (world.Hit(r, 0.001f, float.PositiveInfinity, out var hit))
        {
            var emitted = hit.Material.Emitted(r, hit);

            if (!hit.Material.Scatter(r, hit, sampler, out var scattered, out var attenuation))
                return emitted;

            // Diffuse throughput update (component-wise for RGB):
            // L = Le + attenuation ⊙ Li(scattered)
            var incoming = Li(scattered, world, sampler, depth - 1);
            return emitted + Vec3.Hadamard(attenuation, incoming);
        }

        // Background is black for Cornell-style scenes.
        return Vec3.Zero;
    }
}
