using Tracer.Core.Math;
using Tracer.Core.Scene;
using Tracer.Core.Sampling;

namespace Tracer.Core.Materials;

/// <summary>
/// Material interface for path tracing.
/// 
/// Milestone 3:
/// - Supports emitted radiance (area lights / emissive surfaces)
/// - Supports diffuse scattering (Lambertian)
/// 
/// Later milestones will extend this with specular, transmission, microfacet, PDFs and MIS.
/// </summary>
public interface IMaterial
{
    /// <summary>
    /// Emitted radiance at the hit point for the given outgoing direction.
    /// For non-emissive materials, return Vec3.Zero.
    /// </summary>
    Vec3 Emitted(in Ray rayIn, in HitRecord hit);

    /// <summary>
    /// Samples a scattered ray direction.
    /// Returns true if scattering occurred; false means the path terminates at this surface.
    /// 
    /// For Milestone 3, we only implement diffuse scattering.
    /// </summary>
    bool Scatter(in Ray rayIn, in HitRecord hit, Sampler sampler, out Ray scattered, out Vec3 attenuation);
}
