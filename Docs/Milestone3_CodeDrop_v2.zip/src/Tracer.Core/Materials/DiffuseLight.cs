using Tracer.Core.Math;
using Tracer.Core.Scene;
using Tracer.Core.Sampling;

namespace Tracer.Core.Materials;

/// <summary>
/// Diffuse area light / emissive material.
/// 
/// For Milestone 3 we treat emission as a constant radiance (linear RGB) and do not scatter.
/// </summary>
public sealed class DiffuseLight : IMaterial
{
    public Vec3 Radiance { get; }

    public DiffuseLight(in Vec3 radiance) => Radiance = radiance;

    public Vec3 Emitted(in Ray rayIn, in HitRecord hit)
    {
        // Emit only from the front face to avoid lighting the scene from the "back" of a thin rectangle.
        return hit.FrontFace ? Radiance : Vec3.Zero;
    }

    public bool Scatter(in Ray rayIn, in HitRecord hit, Sampler sampler, out Ray scattered, out Vec3 attenuation)
    {
        scattered = default;
        attenuation = Vec3.Zero;
        return false;
    }
}
