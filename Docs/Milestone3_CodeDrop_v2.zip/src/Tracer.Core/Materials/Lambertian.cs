using Tracer.Core.Math;
using Tracer.Core.Scene;
using Tracer.Core.Sampling;

namespace Tracer.Core.Materials;

/// <summary>
/// Lambertian diffuse material.
/// 
/// BSDF: f = albedo / pi
/// We sample directions using cosine-weighted hemisphere sampling with pdf = cos(theta)/pi.
/// Under this sampling choice:
///   (f * cos(theta)) / pdf = albedo
/// so the path throughput update becomes simply multiplication by albedo.
/// 
/// This is mathematically equivalent to the full estimator but simpler for Milestone 3.
/// </summary>
public sealed class Lambertian : IMaterial
{
    public Vec3 Albedo { get; }

    public Lambertian(in Vec3 albedo) => Albedo = albedo;

    public Vec3 Emitted(in Ray rayIn, in HitRecord hit) => Vec3.Zero;

    public bool Scatter(in Ray rayIn, in HitRecord hit, Sampler sampler, out Ray scattered, out Vec3 attenuation)
    {
        Vec3 wiLocal = CosineSampleHemisphere(sampler);
        Vec3 wi = ToWorld(wiLocal, hit.Normal);

        scattered = new Ray(hit.Point, wi, rayIn.Time);
        attenuation = Albedo;
        return true;
    }

    private static Vec3 CosineSampleHemisphere(Sampler s)
    {
        float u1 = s.Next1D();
        float u2 = s.Next1D();

        float r = float.Sqrt(u1);
        float theta = MathUtil.TwoPi * u2;

        float x = r * float.Cos(theta);
        float y = r * float.Sin(theta);
        float z = float.Sqrt(1f - u1);

        return new Vec3(x, y, z);
    }

    private static Vec3 ToWorld(in Vec3 local, in Vec3 n)
    {
        // Build an orthonormal basis (u,v,w) from n
        Vec3 w = n;
        Vec3 a = float.Abs(w.X) > 0.9f ? Vec3.UnitY : Vec3.UnitX;
        Vec3 v = Vec3.Cross(w, a).Normalized();
        Vec3 u = Vec3.Cross(v, w);

        // local is in hemisphere around +Z in local coordinates
        return (u * local.X + v * local.Y + w * local.Z).Normalized();
    }
}
