
using System;
using Tracer.Core.Camera;
using Tracer.Core.Math;
using Tracer.Core.Rendering;
using Tracer.Core.Scene;
using Tracer.Core.Materials;

int width = 400;
int height = 225;
int spp = 50;
string outPath = "milestone2.ppm";

if (args.Length >= 3)
{
    int.TryParse(args[0], out width);
    int.TryParse(args[1], out height);
    int.TryParse(args[2], out spp);
}
if (args.Length >= 4) outPath = args[3];

float aspect = (float)width / height;

var world = new HittableList();
world.Add(new Sphere(new Vec3(0f, 0f, -1f), 0.5f));
world.Add(new Sphere(new Vec3(0f, -100.5f, -1f), 100f));

var camera = new PinholeCamera(60f, aspect, new Vec3(0f, 0.5f, 1.5f), new Vec3(0f, 0f, -1f), Vec3.UnitY);
var lambert = new Lambertian(new Vec3(0.8f, 0.8f, 0.8f));

Console.WriteLine($"Rendering {width}x{height}, spp={spp}");
var pixels = PathTracer.Render(width, height, spp, camera, world, lambert);
PpmWriter.WriteP6(outPath, width, height, pixels);
Console.WriteLine("Done.");
