using System;
using System.IO;
using Tracer.Core.Math;

namespace Tracer.Core.Testing;

/// <summary>
/// Tiny binary format for golden images.
/// Stores width, height, and float RGB for each pixel (linear space).
/// This avoids gamma/tone-mapping differences and stays stable across platforms.
/// 
/// File layout (little-endian):
///   char[4] magic = 'PTGI'
///   int32 width
///   int32 height
///   float32 rgb[width*height*3]  (row-major, top-to-bottom)
/// </summary>
public static class ImageIO
{
    private const uint Magic = 0x49544750; // 'PTGI' little-endian

    public static void Save(string path, int width, int height, ReadOnlySpan<Vec3> pixels)
    {
        if (pixels.Length != width * height)
            throw new ArgumentException("Pixel buffer size mismatch", nameof(pixels));

        Directory.CreateDirectory(Path.GetDirectoryName(path) ?? ".");

        using var fs = File.Create(path);
        using var bw = new BinaryWriter(fs);
        bw.Write(Magic);
        bw.Write(width);
        bw.Write(height);

        for (int i = 0; i < pixels.Length; i++)
        {
            bw.Write(pixels[i].X);
            bw.Write(pixels[i].Y);
            bw.Write(pixels[i].Z);
        }
    }

    public static (int width, int height, Vec3[] pixels) Load(string path)
    {
        using var fs = File.OpenRead(path);
        using var br = new BinaryReader(fs);

        uint magic = br.ReadUInt32();
        if (magic != Magic)
            throw new InvalidDataException($"Not a PTGI file: {path}");

        int width = br.ReadInt32();
        int height = br.ReadInt32();
        int count = checked(width * height);

        var pixels = new Vec3[count];
        for (int i = 0; i < count; i++)
        {
            float r = br.ReadSingle();
            float g = br.ReadSingle();
            float b = br.ReadSingle();
            pixels[i] = new Vec3(r, g, b);
        }

        return (width, height, pixels);
    }
}
