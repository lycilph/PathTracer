using System;
using Tracer.Core.Math;

namespace Tracer.Core.Testing;

public static class ImageMetrics
{
    /// <summary>
    /// Root mean squared error (RMSE) over all channels.
    /// Computed in linear space.
    /// </summary>
    public static float Rmse(ReadOnlySpan<Vec3> a, ReadOnlySpan<Vec3> b)
    {
        if (a.Length != b.Length)
            throw new ArgumentException("Image size mismatch");

        double sum = 0.0;
        long n = (long)a.Length * 3;

        for (int i = 0; i < a.Length; i++)
        {
            double dr = a[i].X - b[i].X;
            double dg = a[i].Y - b[i].Y;
            double db = a[i].Z - b[i].Z;
            sum += dr * dr + dg * dg + db * db;
        }

        return (float)System.Math.Sqrt(sum / n);
    }

    /// <summary>
    /// Peak signal-to-noise ratio (PSNR) assuming peak value 1.0.
    /// Returns +inf when rmse=0.
    /// </summary>
    public static float PsnrFromRmse(float rmse, float peak = 1.0f)
    {
        if (rmse <= 0f) return float.PositiveInfinity;
        return 20f * (float)System.Math.Log10(peak / rmse);
    }

    public static bool AllFiniteNonNegative(ReadOnlySpan<Vec3> a)
    {
        for (int i = 0; i < a.Length; i++)
        {
            var c = a[i];
            if (float.IsNaN(c.X) || float.IsNaN(c.Y) || float.IsNaN(c.Z)) return false;
            if (float.IsInfinity(c.X) || float.IsInfinity(c.Y) || float.IsInfinity(c.Z)) return false;
            if (c.X < 0f || c.Y < 0f || c.Z < 0f) return false;
        }
        return true;
    }
}
