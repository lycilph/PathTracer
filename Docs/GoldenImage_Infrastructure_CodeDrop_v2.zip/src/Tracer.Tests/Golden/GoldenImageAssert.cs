using System;
using System.IO;
using Tracer.Core.Math;
using Tracer.Core.Testing;
using Xunit;

namespace Tracer.Tests.Golden;

public static class GoldenImageAssert
{
    /// <summary>
    /// Loads a golden image from disk and asserts RMSE under a threshold.
    /// If UPDATE_GOLDENS=1 is set in environment variables, it will write the new golden image instead.
    /// </summary>
    public static void Matches(string goldenPath, int width, int height, Vec3[] actual, float rmseThreshold)
    {
        Assert.Equal(width * height, actual.Length);
        Assert.True(ImageMetrics.AllFiniteNonNegative(actual), "Actual image contains NaN/Inf/negative values");

        bool update = Environment.GetEnvironmentVariable("UPDATE_GOLDENS") == "1";

        if (update || !File.Exists(goldenPath))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(goldenPath) ?? ".");
            ImageIO.Save(goldenPath, width, height, actual);
            // In update mode we don't fail. The point is to intentionally refresh goldens.
            return;
        }

        var (gw, gh, golden) = ImageIO.Load(goldenPath);
        Assert.Equal(width, gw);
        Assert.Equal(height, gh);

        float rmse = ImageMetrics.Rmse(golden, actual);
        float psnr = ImageMetrics.PsnrFromRmse(rmse);

        Assert.True(rmse <= rmseThreshold,
            $"Golden mismatch. RMSE={rmse} (threshold {rmseThreshold}), PSNR={psnr} dB. Golden={goldenPath}");
    }
}
