# Golden files

This folder contains `.ptgi` golden images.

To generate/update them:

- Set environment variable `UPDATE_GOLDENS=1`
- Run `dotnet test`

The test suite will write/update the golden files.

Example:

```bash
UPDATE_GOLDENS=1 dotnet test
```
